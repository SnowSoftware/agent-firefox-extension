
function closeWindow()
{
  window.close();
}

function decline() {
  let uninstalling = browser.management.uninstallSelf({
    showConfirmDialog: true,
  });

  uninstalling.then(closeWindow, closeWindow);
}

document.querySelector('#accept').addEventListener('click', closeWindow)
document.querySelector('#decline').addEventListener('click', decline)

// Must prevent form from submitting so that the page isn't reloaded
// which prevents handling the return value,
document.querySelector('#consentform').onsubmit = () => { return false; }
